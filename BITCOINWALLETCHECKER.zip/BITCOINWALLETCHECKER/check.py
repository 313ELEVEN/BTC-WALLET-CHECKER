import logging
from time import sleep
import requests
import json
from btcaddr import Wallet
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configure random user agent
software_names = [SoftwareName.CHROME.value]
operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems, limit=100)

def generate_addresses(count):
    addresses = {}
    for i in range(count):
        wallet = Wallet()
        pub = wallet.address.__dict__["mainnet"].__dict__["pubaddr1"]
        prv = wallet.key.__dict__["mainnet"].__dict__["wif"]
        addresses[pub] = prv
    return addresses

def check_balance_btc(data=generate_addresses(100)):
    try:
        addresses = "|".join(data.keys())
        headers = {
            "User-Agent": user_agent_rotator.get_random_user_agent()
        }
        url = f"https://blockchain.info/multiaddr?active={addresses}"
        response = requests.get(url, headers=headers).json()
        sleep(0.5)
        extract = []
        for address in response["addresses"]:
            extract.append({
                "address": address["address"],
                "balance": address["final_balance"],
                "private": data[address["address"]]
            })
        return extract
    except Exception as e:
        logger.error(f"Error checking balance: {e}")
        return []

# Optional function for future use
"""
def last_seen_bc(address):
    try:
        address = address
        reading_state = 1
        while reading_state:
            try:
                htmlfile = urlopen(
                    f"https://blockchain.info/q/addressfirstseen/{address}?format=json",
                    timeout=10,
                )
                htmltext = htmlfile.read().decode("utf-8")
                reading_state = 0
            except:
                reading_state += 1
                sleep(60 * reading_state)
        ts = int(htmltext)
        if ts == 0:
            return 0
        return str(datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S"))
    except:
        return None
"""